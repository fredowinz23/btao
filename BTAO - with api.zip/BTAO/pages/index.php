<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
?>

<br>

<center>
<h2>BTAO: <br>  Bacolod Traffic Authority Office</h2>
</center>



<?php include $ROOT_DIR . "templates/footer.php"; ?>
