<?php
$ROOT_DIR="../";
$pageName = "&nbsp";
include $ROOT_DIR . "user-templates/header.php";

?>

<div class="row">
  <div class="col-lg-12">
<div class="box text-center" style="height:300px;">

  <h3 class="mt-5">You have Successfully Placed an Order</h3>
  <a href="index.php" class="btn btn-primary mt-3">Done</a>

    </div>

    </div>

<?php include $ROOT_DIR . "user-templates/footer.php"; ?>
